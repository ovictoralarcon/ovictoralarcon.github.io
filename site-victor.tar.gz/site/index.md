---
layout: default
title: Victor Alarcon
description: Artista visual, xilogravador, professor. São Paulo.
---

<section class="home-hero">
  <div class="container">
    <div class="home-hero__eyebrow">
      <span class="label">São Paulo, Brasil</span>
    </div>
    <h1 class="home-hero__nome">Victor Alarcon</h1>
    <p class="home-hero__descricao">Artista visual, xilogravador, professor.</p>
  </div>
</section>

<section class="home-sections">
  <div class="container">
    <div class="home-sections__grid">

      <a href="{{ '/obras/' | relative_url }}" class="home-section-item">
        <span class="home-section-item__numero">01</span>
        <h2 class="home-section-item__titulo">Obras</h2>
        <p class="home-section-item__descricao">Xilogravura, têmpera de ovo, gouache, escultura. Animais como figuras políticas.</p>
        <span class="home-section-item__link">Ver obras</span>
      </a>

      <a href="{{ '/oficinas/' | relative_url }}" class="home-section-item">
        <span class="home-section-item__numero">02</span>
        <h2 class="home-section-item__titulo">Oficinas</h2>
        <p class="home-section-item__descricao">Aulas individuais e em grupo. Gouache, têmpera de ovo, fundamentos da pintura.</p>
        <span class="home-section-item__link">Ver oficinas</span>
      </a>

      <a href="{{ '/textos/' | relative_url }}" class="home-section-item">
        <span class="home-section-item__numero">03</span>
        <h2 class="home-section-item__titulo">Textos</h2>
        <p class="home-section-item__descricao">Crítica, teoria e técnica. Sobre arte, materiais e o que fica quando a imagem vai embora.</p>
        <span class="home-section-item__link">Ler textos</span>
      </a>

      <a href="{{ '/sobre/' | relative_url }}" class="home-section-item">
        <span class="home-section-item__numero">04</span>
        <h2 class="home-section-item__titulo">Sobre</h2>
        <p class="home-section-item__descricao">Formação, poética, trajetória.</p>
        <span class="home-section-item__link">Sobre o trabalho</span>
      </a>

    </div>
  </div>
</section>

<section class="home-canais">
  <div class="container">
    <p class="home-canais__titulo">Canais</p>
    <div class="home-canais__lista">

      <div class="home-canal">
        <span class="home-canal__nome">YouTube</span>
        <p class="home-canal__desc">Crítica e teoria da arte em vídeo.</p>
        <a href="https://youtube.com/@ovictoralarcon" target="_blank" rel="noopener">Assistir →</a>
      </div>

      <div class="home-canal">
        <span class="home-canal__nome">Substack</span>
        <p class="home-canal__desc">Textos sobre arte, materiais e processo.</p>
        <a href="https://substack.com/@ovictoralarcon" target="_blank" rel="noopener">Ler →</a>
      </div>

      <div class="home-canal">
        <span class="home-canal__nome">Instagram</span>
        <p class="home-canal__desc">Processo, obras e registros de ateliê.</p>
        <a href="https://instagram.com/ovictoralarcon" target="_blank" rel="noopener">Ver →</a>
      </div>

    </div>
  </div>
</section>
